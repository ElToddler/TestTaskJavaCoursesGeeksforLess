package steps;

import java.util.Scanner;

public class gettingTheExpression {
    public static void main(String[] args){
   Scanner expression = new Scanner(System.in);
   System.out.println("Enter your expression:");//scanner asks to input the expression
   String NewExpression = expression.nextLine();
    }
}
